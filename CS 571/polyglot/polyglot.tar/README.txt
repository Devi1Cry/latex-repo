Zachary Seymour
zseymou1@binghamton.edu

All classes of the form ***_c.java have been ignored.